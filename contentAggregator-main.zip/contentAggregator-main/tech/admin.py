# from django.contrib import admin
# from tech.models import TechSite, TechArticle

# # Register your models here.
# admin.site.register(TechSite)
# admin.site.register(TechArticle)
