from contentAggregator import Site

__sites = [
    Site('Stack Overflow','stackoverflow', 'https://www.stackoverflow.com/', 'https://feeds.feedburner.com/stack-overflow'),
    # Site('TechCrunch','techcrunch' , 'https://techcrunch.com/', 'https://techcrunch.com/feed/'),
    Site('TechCrunch','techcrunch' , 'https://techcrunch.com/', 'https://feeds.feedburner.com/techcrunch'),
    # Site('The Crazy Programmer','thecrazyprogrammer', 'https://www.thecrazyprogrammer.com/', 'https://www.thecrazyprogrammer.com/feed'),
    Site('The Crazy Programmer','thecrazyprogrammer', 'https://www.thecrazyprogrammer.com/', 'https://feeds.feedburner.com/thecrazyprogrammer'),
    # Site('TechRepublic','techrepublic', 'https://www.techrepublic.com/', 'https://www.techrepublic.com/rssfeeds/articles/'),
]