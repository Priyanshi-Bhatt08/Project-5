# from django.contrib import admin
# from news.models import Site, Article

# # Register your models here.
# admin.site.register(Site)
# admin.site.register(Article)
