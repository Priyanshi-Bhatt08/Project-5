class Site:
    def __init__(self, name, short_name, url, rss_link):
        self.name = name
        self.short_name = short_name
        self.url = url
        self.rss_link = rss_link